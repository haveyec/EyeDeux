# videojs-sublime-skin
> A [Video.js][] skin modeled on [SublimeVideo][].

[Video.js]: http://www.videojs.com/
[SublimeVideo]: http://www.sublimevideo.net/

![](screenshot.png)

Install via bower:

    % bower install --save videojs-sublime-skin

Then include `dist/videojs-sublime-skin.min.css` in your HTML, and replace the
`vjs-default-skin` in the class of your `video` elements with
`vjs-sublime-skin`.

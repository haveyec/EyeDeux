
	<!-- BEGIN FOOTER -->
    <footer id="footer">
    	<div id="footer-bottom">
        <div class="container-large">
          <div class="row">
            <div class="col-sm-12 t-center">
              <p class="copyright">
		&copy;<?php echo date("Y"); ?> <?php bloginfo( 'name' ); ?>. All rights reserved.
		<br><?php echo nerd_gang(); ?></p>
		 </div>
          </div>
        </div>
      </div>
	</footer>

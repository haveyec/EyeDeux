<script src="<?php echo get_scripts_path(); ?>libs/jquery/dist/jquery.min.js"></script>
  <script src="<?php echo get_scripts_path(); ?>libs/jquery-ui/jquery-ui.min.js"></script>
  <script src="<?php echo get_scripts_path(); ?>libs/gsap/src/minified/TweenMax.min.js"></script>
  <script src="<?php echo get_scripts_path(); ?>libs/gsap/src/minified/plugins/ScrollToPlugin.min.js"></script>
  <script src="<?php echo get_scripts_path(); ?>libs/tether/dist/js/tether.min.js"></script>
  <script src="<?php echo get_scripts_path(); ?>libs/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="<?php echo get_scripts_path(); ?>libs/superfish/dist/js/superfish.min.js"></script>
  <script src="<?php echo get_scripts_path(); ?>libs/appear/jquery.appear.js"></script>
  <script src="<?php echo get_scripts_path(); ?>libs/skrollr/dist/skrollr.min.js"></script>  
  <script src="<?php echo get_scripts_path(); ?>libs/easyticker-jquery/jquery.easy-ticker.min.js"></script>
  
  <!-- BEGIN PAGE SCRIPT -->
  <script src="<?php echo get_scripts_path(); ?>blast.js"></script>
  <script src="<?php echo get_scripts_path(); ?>jquery-parallax-scroll.js"></script>
  <script src="<?php echo get_scripts_path(); ?>libs/velocity/velocity.min.js"></script>
  <script src="<?php echo get_scripts_path(); ?>libs/velocity/velocity.ui.min.js"></script>
  <script src="<?php echo get_scripts_path(); ?>libs/jquery-countTo/jquery.countTo.js"></script>
  <script src="<?php echo get_scripts_path(); ?>libs/jQuery-One-Page-Nav/jquery.nav.js"></script>
  <script src="<?php echo get_scripts_path(); ?>masonry.js"></script>
  <script src="<?php echo get_scripts_path(); ?>widgets.js"></script>
  <!-- END PAGE SCRIPT -->

  <script src="<?php echo get_scripts_path(); ?>navigation.js"></script>
  <script src="<?php echo get_scripts_path(); ?>search.js"></script>
  <script src="<?php echo get_scripts_path(); ?>builder.js"></script>
  <script src="<?php echo get_scripts_path(); ?>main.js"></script>
	<?php wp_footer(); ?>
	</body>
</html>